# Patient_Service constants

# Database configuration
DATABASE_FILE = "patient_service.db"

# MQTT Configuration
MQTT_BROKER = "135.235.145.253"
MQTT_PORT = 1883

# MQTT Topics
MQTT_TOPIC_TEST_SUBMISSION = "hospital/test_submission"

# File directories
TEST_DIR = "Submitted_Test"