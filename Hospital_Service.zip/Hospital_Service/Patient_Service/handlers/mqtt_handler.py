import os
import sqlite3
import paho.mqtt.client as mqtt
import json

from Hospital_Service.Patient_Service.config.constants import MQTT_BROKER, MQTT_PORT, MQTT_TOPIC_TEST_SUBMISSION
from Hospital_Service.Patient_Service.utils.logger import logger


def on_connect(client, userdata, flags, rc):
    logger.info("Patient Service connected to MQTT Broker!")
    client.subscribe(MQTT_TOPIC_TEST_SUBMISSION)


def on_message(client, userdata, msg):
    logger.info(f"Message received on topic: {msg.topic}")

    # No specific action needed for now as Patient Service primarily just sends data
    # But can be implemented in the future if needed


mqtt_client = mqtt.Client()
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message


def start_mqtt_client():
    try:
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        mqtt_client.loop_start()
        logger.info("MQTT client started")
    except Exception as e:
        logger.error(f"Failed to connect to MQTT broker: {str(e)}")