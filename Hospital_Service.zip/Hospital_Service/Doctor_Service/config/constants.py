DATABASE_FILE = "doctor_service.db"

MQTT_BROKER = "135.235.145.253"
MQTT_PORT = 1883

MQTT_TOPIC_TEST_REQUEST = "hospital/test_request"
MQTT_TOPIC_TEST_RESULT = "hospital/test_result"

REPORT_DIR = "Submitted_Report"