import logging

logging.basicConfig(
    filename="Doctor_Patient_System.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

logger = logging.getLogger("MQTT_Logger")
