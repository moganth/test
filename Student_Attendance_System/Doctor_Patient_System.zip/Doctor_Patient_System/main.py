import uvicorn
from fastapi import FastAPI

from api.producer_api import router as producer_router
from api.consumer_api import router as consumer_router
from api.prescription_api import router as prescription_router
from api.test_api import router as test_router

from scripts.init_db import initialize_db, initialize_db_1

app = FastAPI()

initialize_db()
initialize_db_1()

app.include_router(producer_router, tags=["Patient"])
app.include_router(consumer_router, tags=["Doctor"])
app.include_router(prescription_router, tags=["Prescription"])
app.include_router(test_router, tags=["Reports"])

if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=12354)