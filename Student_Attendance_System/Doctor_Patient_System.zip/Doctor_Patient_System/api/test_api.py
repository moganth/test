import os

from fastapi import APIRouter, HTTPException

Report = "Submitted_Report"

os.makedirs(Report, exist_ok=True)

router = APIRouter()

from fastapi.responses import FileResponse

@router.get("/download_report/{file_name}")
def download_report(file_name: str):
    file_path = os.path.join(Report, file_name)

    if os.path.exists(file_path):
        return FileResponse(file_path, media_type="application/octet-stream", filename=file_name)

    raise HTTPException(status_code=404, detail="File not found")
